# NVSD ItemView for REAPER

**Ableton-Style Clip View for REAPER Audio Items**

NVSD ItemView brings Ableton Live's intuitive clip editing workflow to REAPER. See your entire audio source at a glance, drag markers to control playback boundaries, and adjust pitch and gain—all from a single, elegant window.

---

## What It Does

REAPER shows you only the portion of audio that's currently in your item. But what about the rest of your source file? What if you want to quickly shift which part plays, extend into unused sections, or loop beyond the original boundaries?

**NVSD ItemView solves this** by displaying a complete waveform of your source audio with draggable markers showing exactly which portion your item plays. It's the missing clip view that Ableton users have been wanting in REAPER.

### Key Features

- **Full Source Waveform** - See your entire audio file, not just the item boundaries
- **Draggable Start/End Markers** - Visually adjust which portion of the source plays
- **Looping Support** - Extend items beyond source boundaries with visual loop indicators
- **Gain Slider** - Adjust item volume from +24dB to -∞ with logarithmic control
- **Pitch Control** - Transpose up to ±48 semitones with cent-level precision
- **WARP Mode** - Toggle between time-stretch (preserve length) and playrate modes
- **Pitch Algorithm Selector** - Choose from Elastique, SoundTouch, Rubber Band, and more
- **Multi-Channel Display** - Stereo and multi-channel files display as stacked waveforms
- **Smart Zoom** - Ctrl+scroll or drag the ruler to zoom; always keeps markers visible
- **Timeline Integration** - Shows bar numbers, time ruler, and REAPER's time selection
- **Quick Marker Positioning** - Mouse button 4/5 to instantly set start/end markers
- **Mute Toggle** - One-click mute directly in the info bar
- **Reverse & Edit Buttons** - Quick access to reverse audio and open in external editor
- **Auto-Reload** - Script automatically reloads when you save changes during development

---

## Compatibility

| Requirement | Details |
|-------------|---------|
| **REAPER Version** | 6.0 or higher |
| **Language** | Lua |
| **Required Extension** | [ReaImGui](https://forum.cockos.com/showthread.php?t=250419) (install via ReaPack) |
| **Optional Extension** | [SWS/S&M](https://www.sws-extension.org/) - Enables reverse detection and edge-drag waveform display |
| **Optional Extension** | [js_ReaScriptAPI](https://forum.cockos.com/showthread.php?t=212174) - Enables cursor lock during drag operations |

### Installing Extensions

1. **ReaImGui** (Required):
   - Open REAPER → Extensions → ReaPack → Browse packages
   - Search for "ReaImGui" and install
   - Restart REAPER

2. **SWS Extension** (Recommended):
   - Download from [sws-extension.org](https://www.sws-extension.org/)
   - Run the installer
   - Restart REAPER

3. **js_ReaScriptAPI** (Optional):
   - Open REAPER → Extensions → ReaPack → Browse packages
   - Search for "js_ReaScriptAPI" and install
   - Restart REAPER

---

## Installation

1. Copy `NVSD_ItemView.lua` to your REAPER Scripts folder:
   - Windows: `%APPDATA%\REAPER\Scripts\`
   - macOS: `~/Library/Application Support/REAPER/Scripts/`
   - Linux: `~/.config/REAPER/Scripts/`

2. In REAPER, go to Actions → Show action list
3. Click "Load ReaScript..." and select `NVSD_ItemView.lua`
4. (Optional) Assign a keyboard shortcut or add to toolbar

---

## How to Use

### Basic Workflow

1. **Select an audio item** in REAPER's arrange view
2. **Run the script** - The ItemView window opens showing the full source waveform
3. **Blue markers** indicate start/end of what the item plays
4. **Orange brackets** in the ruler show original source boundaries
5. **Drag markers** to change which portion plays
6. **Gray overlays** show unused (light) and looped (dark) regions

### Controls

| Action | Effect |
|--------|--------|
| **Drag blue markers** | Adjust item start/end within source |
| **Alt + drag marker** | Slide both markers together (shift source position) |
| **Mouse button 4** | Set start marker to cursor position |
| **Mouse button 5** | Set end marker to cursor position |
| **Middle mouse drag** | Pan the waveform view |
| **Ctrl + scroll** | Zoom in/out centered on cursor |
| **Drag ruler up/down** | Zoom in/out |
| **Double-click gain slider** | Reset to 0 dB |
| **Double-click pitch knob** | Reset to 0 semitones |
| **Shift + drag** | Fine adjustment for gain/pitch controls |
| **Click mute square** | Toggle item mute |
| **Click file name** | Open source in Media Explorer |

### Left Panel

- **WARP Button** - Toggle between pitch-shift (WARP on) and playrate modes
- **Algorithm Dropdown** - Select pitch-shifting algorithm (only when WARP is on)
- **Reverse Button** - Reverse the audio
- **Edit Button** - Open in external audio editor
- **Gain Slider** - Adjust item volume (+24dB to -∞)
- **Pitch Knob** - Adjust pitch (±48 semitones)
- **Semitones/Cents Boxes** - Drag for precise pitch adjustment

### Visual Guide

- **Blue markers & border** - Item playback boundaries
- **Orange brackets** - Original source file boundaries
- **Light gray overlay** - Source audio not currently used
- **Dark gray overlay** - Looped content (beyond source boundaries)
- **Dashed lines** - Source/loop boundaries
- **Green waveform** - Active playback region
- **Muted green waveform** - Inactive/unused regions

---

## Tips & Tricks

- **Extend into loops**: Drag the end marker past the source boundary to create loops
- **Negative start offset**: Drag the start marker before 0 to start playback from a loop
- **Quick auditioning**: The waveform updates in real-time as you drag
- **Dock the window**: Right-click the title bar to dock alongside other REAPER windows
- **Edge-drag workflow**: Click and hold an item's edge in REAPER to see its waveform without selecting it

---

## Troubleshooting

**Window doesn't appear:**
- Make sure ReaImGui is installed and REAPER was restarted

**"This script requires ReaImGui" error:**
- Install ReaImGui via ReaPack and restart REAPER

**Waveform doesn't show when dragging item edges:**
- Install the SWS Extension for this feature

**Cursor jumps during drag operations:**
- Install js_ReaScriptAPI for smooth cursor locking

**MIDI items show "MIDI items not supported":**
- This script is designed for audio items only

---

## License

This script is provided as-is. You may use it for personal and commercial music production.

---

## Support

For issues, feature requests, or questions, please contact the author.

---

*Made with care for the REAPER community*
